# NEXUS – offline video player (Android)

Kotlin, native Android (XML + RecyclerView), Media3 ExoPlayer (from Stage 3), Room.
Package: `com.nexus.videoplayer` · minSdk 26 (Android 8) · ABIs: armeabi-v7a + arm64-v8a.

## Build
Push to GitHub. Actions (`.github/workflows/build.yml`) runs unit tests and builds both APKs.
Download them from the run page under **Artifacts**: `NEXUS-debug-apk` and `NEXUS-release-apk`.

Local build (Android Studio, or Gradle 8.9 + JDK 17 + Android SDK 35): `gradle :app:assembleDebug`

## Signing
Both APKs are signed with the shared CI key in `keystore/nexus-ci.jks` so each stage installs over the
previous one. That key is public: for a real release, add repo secrets `NEXUS_KEYSTORE_BASE64`,
`NEXUS_KEYSTORE_PASSWORD`, `NEXUS_KEY_ALIAS`, `NEXUS_KEY_PASSWORD` and the release APK uses your key.

## Status
- [x] Stage 1: setup, architecture, permissions, MediaStore scanning, Room, CI
