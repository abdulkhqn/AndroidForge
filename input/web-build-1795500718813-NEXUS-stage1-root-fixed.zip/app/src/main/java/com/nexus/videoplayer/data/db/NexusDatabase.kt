package com.nexus.videoplayer.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

// Schemas are exported to app/schemas so later stages can add proper migrations
// (history and favorites must survive updates, so we never use destructive migration).
@Database(entities = [VideoEntity::class], version = 1, exportSchema = true)
abstract class NexusDatabase : RoomDatabase() {

    abstract fun videoDao(): VideoDao

    companion object {
        fun create(context: Context): NexusDatabase =
            Room.databaseBuilder(context.applicationContext, NexusDatabase::class.java, "nexus.db")
                .build()
    }
}
