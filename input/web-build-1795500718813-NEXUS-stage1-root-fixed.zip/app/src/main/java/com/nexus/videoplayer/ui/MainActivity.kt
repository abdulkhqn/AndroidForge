package com.nexus.videoplayer.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.format.Formatter
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.nexus.videoplayer.AppContainer
import com.nexus.videoplayer.NexusApp
import com.nexus.videoplayer.R
import com.nexus.videoplayer.databinding.ActivityMainBinding
import com.nexus.videoplayer.domain.Category
import com.nexus.videoplayer.util.PermissionHelper
import com.nexus.videoplayer.util.PermissionHelper.Access
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()
    private val adapter = FolderAdapter()

    private val container: AppContainer get() = (application as NexusApp).container

    private var access = Access.NONE
    private var uiState = LibraryUiState()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            onAccessMayHaveChanged(forceScan = true)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Same edge-to-edge behaviour on every Android version (it is mandatory on Android 15).
        WindowCompat.setDecorFitsSystemWindows(window, false)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        WindowCompat.getInsetsController(window, binding.root).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { view, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        binding.toolbar.inflateMenu(R.menu.main_menu)
        binding.toolbar.setOnMenuItemClickListener { item ->
            if (item.itemId == R.id.action_refresh && access != Access.NONE) {
                viewModel.refresh(force = true)
                true
            } else {
                false
            }
        }

        binding.folderList.layoutManager = LinearLayoutManager(this)
        binding.folderList.setHasFixedSize(true)
        binding.folderList.adapter = adapter

        binding.permissionGroup.grantButton.setOnClickListener {
            if (PermissionHelper.mustOpenSettings(this, container.prefs.permissionRequested)) {
                openAppSettings()
            } else {
                requestPermission()
            }
        }
        binding.limitedAction.setOnClickListener { requestPermission() }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.state.collect { state ->
                    uiState = state
                    render()
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        // Also covers returning from system settings after the user changed the permission.
        onAccessMayHaveChanged(forceScan = false)
    }

    private fun onAccessMayHaveChanged(forceScan: Boolean) {
        access = PermissionHelper.access(this)
        val prefs = container.prefs
        if (access != Access.NONE) {
            container.repository.startObserving()
            // A different access level means a different set of readable videos: rescan.
            val levelChanged = prefs.lastAccess != access.name
            viewModel.refresh(force = forceScan || levelChanged)
        }
        prefs.lastAccess = access.name
        render()
    }

    private fun requestPermission() {
        container.prefs.permissionRequested = true
        permissionLauncher.launch(PermissionHelper.requiredPermissions())
    }

    private fun openAppSettings() {
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", packageName, null)
            }
        )
    }

    private fun render() {
        val granted = access != Access.NONE
        binding.permissionGroup.root.isVisible = !granted
        binding.contentGroup.isVisible = granted

        if (!granted) {
            renderPermissionScreen()
            return
        }

        binding.limitedBanner.isVisible = access == Access.PARTIAL

        val state = uiState
        val showLoading = !state.loaded || (state.scanning && state.folders.isEmpty())
        val showEmpty = !showLoading && state.folders.isEmpty()
        binding.loadingGroup.isVisible = showLoading
        binding.emptyGroup.isVisible = showEmpty
        binding.folderList.isVisible = state.folders.isNotEmpty()

        adapter.submitList(state.folders)

        if (state.folders.isEmpty()) {
            binding.summaryText.isVisible = false
            binding.categoryText.isVisible = false
            return
        }

        val totalVideos = state.folders.sumOf { it.videoCount }
        val totalSize = state.folders.sumOf { it.totalSize }
        var summary = getString(
            R.string.summary_format,
            totalVideos,
            state.folders.size,
            Formatter.formatShortFileSize(this, totalSize)
        )
        if (state.scanning) summary += " · " + getString(R.string.summary_scanning)
        binding.summaryText.text = summary
        binding.summaryText.isVisible = true

        val categoryLine = state.categories
            .map { Category.fromName(it.category) to it.videoCount }
            .sortedBy { it.first.ordinal }
            .joinToString(" · ") { (category, count) ->
                getString(R.string.category_item, category.label(this), count)
            }
        binding.categoryText.text = categoryLine
        binding.categoryText.isVisible = categoryLine.isNotEmpty()
    }

    private fun renderPermissionScreen() {
        val permission = binding.permissionGroup
        val requested = container.prefs.permissionRequested
        val mustOpenSettings = PermissionHelper.mustOpenSettings(this, requested)
        permission.permissionBody.setText(
            when {
                !requested -> R.string.perm_body
                mustOpenSettings -> R.string.perm_body_settings
                else -> R.string.perm_body_denied
            }
        )
        permission.grantButton.setText(
            if (mustOpenSettings) R.string.perm_button_settings else R.string.perm_button_grant
        )
    }
}
