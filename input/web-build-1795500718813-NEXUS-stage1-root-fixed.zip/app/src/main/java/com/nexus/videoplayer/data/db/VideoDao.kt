package com.nexus.videoplayer.data.db

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

data class FolderSummary(
    val folderPath: String,
    val folderName: String,
    val videoCount: Int,
    val totalSize: Long,
    val lastModifiedSec: Long
)

data class CategoryCount(
    val category: String,
    val videoCount: Int
)

data class ManualCategoryRow(
    val id: Long,
    val manualCategory: String?
)

@Dao
interface VideoDao {

    @Upsert
    suspend fun upsertAll(videos: List<VideoEntity>)

    @Query("SELECT id, manualCategory FROM videos WHERE manualCategory IS NOT NULL")
    suspend fun manualCategories(): List<ManualCategoryRow>

    @Query("SELECT id FROM videos")
    suspend fun allIds(): List<Long>

    @Query("DELETE FROM videos WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<Long>)

    @Query("SELECT COUNT(*) FROM videos")
    suspend fun count(): Int

    @Query(
        "SELECT folderPath, folderName, COUNT(*) AS videoCount, " +
            "SUM(sizeBytes) AS totalSize, MAX(dateModifiedSec) AS lastModifiedSec " +
            "FROM videos GROUP BY folderPath ORDER BY folderName COLLATE NOCASE ASC"
    )
    fun observeFolders(): Flow<List<FolderSummary>>

    @Query(
        "SELECT COALESCE(manualCategory, autoCategory) AS category, COUNT(*) AS videoCount " +
            "FROM videos GROUP BY category"
    )
    fun observeCategoryCounts(): Flow<List<CategoryCount>>
}
