# NEXUS ProGuard / R8 rules.
# Room, AndroidX and Kotlin coroutines ship their own consumer rules.
# Keep line numbers for readable crash reports.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
