package com.nexus.videoplayer.domain

import org.junit.Assert.assertEquals
import org.junit.Test

class SourceClassifierTest {

    private fun classify(path: String?, owner: String? = null) =
        SourceClassifier.classify(path, owner)

    @Test
    fun camera() {
        assertEquals(Category.CAMERA, classify("/storage/emulated/0/DCIM/Camera"))
    }

    @Test
    fun screenRecordingBeatsDcim() {
        assertEquals(Category.SCREEN_RECORDINGS, classify("/storage/emulated/0/DCIM/Screen recordings"))
        assertEquals(Category.SCREEN_RECORDINGS, classify("/storage/emulated/0/Movies/Screenrecords"))
    }

    @Test
    fun whatsapp() {
        assertEquals(
            Category.WHATSAPP,
            classify("/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Video")
        )
        assertEquals(Category.WHATSAPP, classify("/storage/emulated/0/Download", "com.whatsapp"))
    }

    @Test
    fun telegram() {
        assertEquals(Category.TELEGRAM, classify("/storage/emulated/0/Movies/Telegram"))
        assertEquals(Category.TELEGRAM, classify("/storage/emulated/0/Download", "org.telegram.messenger"))
    }

    @Test
    fun bluetooth() {
        assertEquals(Category.BLUETOOTH, classify("/storage/emulated/0/Download/Bluetooth"))
        assertEquals(Category.BLUETOOTH, classify("/storage/emulated/0/Download", "com.android.bluetooth"))
    }

    @Test
    fun quickShare() {
        assertEquals(Category.QUICK_SHARE, classify("/storage/emulated/0/Download/Quick Share"))
        assertEquals(Category.QUICK_SHARE, classify("/storage/emulated/0/Download", "com.google.android.gms"))
    }

    @Test
    fun nexusManagedFolder() {
        assertEquals(Category.NEXUS_DOWNLOADS, classify("/storage/emulated/0/Movies/NEXUS"))
        assertEquals(Category.NEXUS_DOWNLOADS, classify("/storage/emulated/0/Download", "com.nexus.videoplayer"))
    }

    @Test
    fun browserDownloadInSharedFolderIsNotGuessed() {
        assertEquals(Category.OTHER, classify("/storage/emulated/0/Download"))
        assertEquals(Category.OTHER, classify("/storage/emulated/0/Download", "com.android.chrome"))
    }

    @Test
    fun missingPathFallsBackToOther() {
        assertEquals(Category.OTHER, classify(null))
        assertEquals(Category.OTHER, classify(""))
    }

    @Test
    fun similarNamesDoNotFalselyMatch() {
        assertEquals(Category.OTHER, classify("/storage/emulated/0/Movies/NexusFan"))
    }
}
