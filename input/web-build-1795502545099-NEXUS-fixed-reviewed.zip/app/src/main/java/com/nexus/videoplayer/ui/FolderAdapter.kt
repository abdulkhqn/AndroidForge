package com.nexus.videoplayer.ui

import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.nexus.videoplayer.R
import com.nexus.videoplayer.data.db.FolderSummary
import com.nexus.videoplayer.databinding.ItemFolderBinding

class FolderAdapter : ListAdapter<FolderSummary, FolderAdapter.Holder>(Diff) {

    class Holder(val binding: ItemFolderBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(ItemFolderBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = getItem(position)
        val context = holder.itemView.context
        val count = context.resources.getQuantityString(
            R.plurals.videos_count, item.videoCount, item.videoCount
        )
        holder.binding.folderName.text = item.folderName
        holder.binding.folderMeta.text = context.getString(
            R.string.folder_meta, count, Formatter.formatShortFileSize(context, item.totalSize)
        )
    }

    private object Diff : DiffUtil.ItemCallback<FolderSummary>() {
        override fun areItemsTheSame(old: FolderSummary, new: FolderSummary) =
            old.folderPath == new.folderPath

        override fun areContentsTheSame(old: FolderSummary, new: FolderSummary) = old == new
    }
}
