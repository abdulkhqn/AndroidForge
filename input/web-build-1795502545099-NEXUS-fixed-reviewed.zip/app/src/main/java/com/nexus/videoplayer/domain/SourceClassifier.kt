package com.nexus.videoplayer.domain

import java.util.Locale

/**
 * Decides where a video came from, using only real metadata: the folder path and (Android 10+)
 * the package that created the file. Pure Kotlin, so it is unit-tested on the JVM.
 *
 * Rule: never guess. When neither the path nor the owner package gives positive evidence
 * (for example a browser download sitting in the shared "Download" folder), the result is OTHER.
 * Users can then move a video to the right category manually.
 */
object SourceClassifier {

    const val NEXUS_PACKAGE = "com.nexus.videoplayer"

    private val SCREEN_MARKERS = listOf(
        "screenrecord", "screen record", "screen_record", "screen-record", "screencast"
    )
    private val QUICK_SHARE_MARKERS = listOf(
        "quick share", "quickshare", "quick_share", "nearby share", "nearbyshare"
    )

    // Owner packages that identify Quick Share / Nearby Share transfers.
    private const val GOOGLE_PLAY_SERVICES = "com.google.android.gms"
    private const val SAMSUNG_QUICK_SHARE = "com.samsung.android.app.sharelive"

    fun classify(folderPath: String?, ownerPackage: String?): Category {
        val path = folderPath.orEmpty().lowercase(Locale.ROOT).replace('\\', '/')
        val owner = ownerPackage.orEmpty().lowercase(Locale.ROOT)
        val segments = path.split('/').filter { it.isNotEmpty() }

        fun anySegment(test: (String) -> Boolean) = segments.any(test)

        // 1. Files created by NEXUS itself, or inside its managed folder (Movies/NEXUS).
        if (owner == NEXUS_PACKAGE ||
            "$path/".contains("/movies/nexus/") ||
            path.contains("/android/data/$NEXUS_PACKAGE")
        ) return Category.NEXUS_DOWNLOADS

        // 2. Screen recordings (checked before Camera: they often live under DCIM too).
        if (anySegment { s -> SCREEN_MARKERS.any { s.contains(it) } }) {
            return Category.SCREEN_RECORDINGS
        }

        // 3. Messaging apps.
        if (owner.startsWith("com.whatsapp") || anySegment { it.startsWith("whatsapp") }) {
            return Category.WHATSAPP
        }
        if (owner.startsWith("org.telegram") ||
            owner == "org.thunderdog.challegram" ||
            anySegment { it.startsWith("telegram") }
        ) return Category.TELEGRAM

        // 4. Bluetooth.
        if (owner.startsWith("com.android.bluetooth") || anySegment { it == "bluetooth" }) {
            return Category.BLUETOOTH
        }

        // 5. Quick Share / Nearby Share.
        if (owner == SAMSUNG_QUICK_SHARE ||
            owner == GOOGLE_PLAY_SERVICES ||
            anySegment { s -> QUICK_SHARE_MARKERS.any { s.contains(it) } }
        ) return Category.QUICK_SHARE

        // 6. Camera.
        if (anySegment { it == "camera" || it == "100andro" } ||
            owner.endsWith(".camera") || owner.contains(".camera.")
        ) return Category.CAMERA

        // 7. Honest fallback.
        return Category.OTHER
    }
}
