package com.nexus.videoplayer.util

import android.content.Context

/** Small non-sensitive flags. User-facing settings arrive in Stage 5. */
class Prefs(context: Context) {

    private val sp = context.applicationContext
        .getSharedPreferences("nexus_prefs", Context.MODE_PRIVATE)

    /** True once we have shown the system permission dialog at least once. */
    var permissionRequested: Boolean
        get() = sp.getBoolean(KEY_PERMISSION_REQUESTED, false)
        set(value) = sp.edit().putBoolean(KEY_PERMISSION_REQUESTED, value).apply()

    /** Access level (FULL / PARTIAL / NONE) the last scan was done with. */
    var lastAccess: String?
        get() = sp.getString(KEY_LAST_ACCESS, null)
        set(value) = sp.edit().putString(KEY_LAST_ACCESS, value).apply()

    /** MediaStore generation (Android 11+) of the last completed scan. */
    var scanGeneration: Long
        get() = sp.getLong(KEY_SCAN_GENERATION, -1L)
        set(value) = sp.edit().putLong(KEY_SCAN_GENERATION, value).apply()

    private companion object {
        const val KEY_PERMISSION_REQUESTED = "permission_requested"
        const val KEY_LAST_ACCESS = "last_access"
        const val KEY_SCAN_GENERATION = "scan_generation"
    }
}
