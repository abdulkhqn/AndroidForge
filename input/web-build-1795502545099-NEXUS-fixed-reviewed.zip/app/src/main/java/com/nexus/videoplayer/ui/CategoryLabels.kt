package com.nexus.videoplayer.ui

import android.content.Context
import com.nexus.videoplayer.R
import com.nexus.videoplayer.domain.Category

fun Category.label(context: Context): String = context.getString(
    when (this) {
        Category.NEXUS_DOWNLOADS -> R.string.cat_nexus_downloads
        Category.QUICK_SHARE -> R.string.cat_quick_share
        Category.CAMERA -> R.string.cat_camera
        Category.SCREEN_RECORDINGS -> R.string.cat_screen_recordings
        Category.WHATSAPP -> R.string.cat_whatsapp
        Category.TELEGRAM -> R.string.cat_telegram
        Category.BLUETOOTH -> R.string.cat_bluetooth
        Category.OTHER -> R.string.cat_other
    }
)
