package com.nexus.videoplayer

import android.app.Application
import com.nexus.videoplayer.data.db.NexusDatabase
import com.nexus.videoplayer.data.repo.LibraryRepository
import com.nexus.videoplayer.data.scan.MediaScanner
import com.nexus.videoplayer.util.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/**
 * Tiny manual dependency container (no DI framework: keeps the app light and start-up fast).
 * Everything heavy is lazy, so nothing is created until first use.
 */
class AppContainer(private val app: Application) {

    /** Long-lived scope for work that must finish even if the Activity goes away (e.g. a scan). */
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val prefs: Prefs by lazy { Prefs(app) }

    val database: NexusDatabase by lazy { NexusDatabase.create(app) }

    val repository: LibraryRepository by lazy {
        LibraryRepository(
            context = app,
            dao = database.videoDao(),
            scanner = MediaScanner(app),
            prefs = prefs,
            scope = appScope
        )
    }
}
