package com.nexus.videoplayer.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.provider.MediaStore
import android.content.ContentValues
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.nexus.videoplayer.NexusApp
import com.nexus.videoplayer.data.db.VideoEntity
import com.nexus.videoplayer.util.PermissionHelper
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job

class MainActivity : AppCompatActivity() {
    private val container get() = (application as NexusApp).container
    private lateinit var list: RecyclerView
    private lateinit var adapter: VideoAdapter
    private lateinit var header: TextView
    private lateinit var search: EditText
    private lateinit var root: LinearLayout
    private var currentFolder: String? = null
    private var mode = "Home"
    private var access = PermissionHelper.Access.NONE
    private var sectionJob: Job? = null
    private var pendingRenameUri: Uri? = null
    private var pendingRenameName: String? = null
    private val mediaRequestLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        val uri = pendingRenameUri
        val newName = pendingRenameName
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            if (uri != null && newName != null) {
                runCatching {
                    contentResolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, newName) }, null, null)
                }
            }
            container.repository.requestRefresh(true)
        }
        pendingRenameUri = null; pendingRenameName = null
    }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { checkAccess() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF000000.toInt(); window.navigationBarColor = 0xFF000000.toInt()
        buildUi()
        checkAccess()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF000000.toInt()); setPadding(0,8,0,0) }
        val top = LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL; setPadding(18,8,18,8) }
        top.addView(TextView(this).apply { text="NEXUS"; textSize=25f; setTextColor(-1); setTypeface(null,1) }, LinearLayout.LayoutParams(0,-2,1f))
        top.addView(Button(this).apply { text="↻"; setOnClickListener { container.repository.requestRefresh(true) } })
        root.addView(top)
        header = TextView(this).apply { text="Your video library"; textSize=13f; setTextColor(0xFFAAAAAA.toInt()); setPadding(18,4,18,8) }
        root.addView(header)
        search = EditText(this).apply {
            hint="Search videos"; setTextColor(-1); setHintTextColor(0xFF888888.toInt())
            setSingleLine(true); setPadding(16,4,16,4)
            setOnEditorActionListener { _,_,_ -> showSearch(text.toString()); true }
        }
        root.addView(search, LinearLayout.LayoutParams(-1,52).apply { setMargins(14,4,14,8) })
        val nav = LinearLayout(this).apply { gravity=Gravity.CENTER; setPadding(6,2,6,8) }
        listOf("Home","Folders","All Videos","History","Favorites","Settings").forEach { label ->
            nav.addView(TextView(this).apply {
                text=label; textSize=11f; gravity=Gravity.CENTER; setTextColor(0xFFBB86FC.toInt()); setPadding(7,10,7,10)
                setOnClickListener { openSection(label) }
            }, LinearLayout.LayoutParams(0,-2,1f))
        }
        root.addView(nav)
        list = RecyclerView(this).apply { layoutManager=LinearLayoutManager(this@MainActivity); setPadding(0,4,0,12); clipToPadding=false }
        adapter = VideoAdapter({ play(it) }, { showVideoMenu(it) })
        list.adapter=adapter
        root.addView(list, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
    }

    private fun checkAccess() {
        access = PermissionHelper.access(this)
        if (access == PermissionHelper.Access.NONE) {
            val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(30,30,30,30) }
            box.addView(TextView(this).apply { text="NEXUS needs video access to build your library."; setTextColor(-1); textSize=17f })
            box.addView(Button(this).apply { text="Grant video access"; setOnClickListener {
                if (PermissionHelper.mustOpenSettings(this@MainActivity, container.prefs.permissionRequested)) {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package",packageName,null)))
                } else {
                    container.prefs.permissionRequested=true
                    permissionLauncher.launch(PermissionHelper.requiredPermissions())
                }
            } })
            root.removeAllViews(); root.addView(box,LinearLayout.LayoutParams(-1,-1)); return
        }
        buildUi()
        container.repository.startObserving()
        container.repository.requestRefresh(false)
        openSection("Home")
    }

    private fun openSection(section: String) {
        sectionJob?.cancel()
        mode=section; currentFolder=null
        header.text=section
        sectionJob = lifecycleScope.launch {
            val dao=container.database.videoDao()
            when(section) {
                "Home", "Folders" -> container.repository.folders.collectLatest { folders ->
                    val rows=folders.map { f ->
                        VideoEntity(id=f.folderPath.hashCode().toLong(),uri="",displayName="📁  ${f.folderName}",
                            folderPath=f.folderPath,folderName=f.folderName,sizeBytes=f.totalSize,durationMs=0,
                            dateAddedSec=0,dateModifiedSec=f.lastModifiedSec,width=0,height=0,mimeType=null,
                            ownerPackage=null,autoCategory="OTHER")
                    }
                    adapter.submit(rows)
                    // Folder rows are opened through a tap handler below when URI is empty.
                }
                "History" -> dao.observeHistory().collectLatest { adapter.submit(it) }
                "Favorites" -> dao.observeFavorites().collectLatest { adapter.submit(it) }
                "Settings" -> showSettings()
                "All Videos" -> dao.observeAllVideos().collectLatest { adapter.submit(it) }
                else -> dao.observeAllVideos().collectLatest { adapter.submit(it) }
            }
        }
    }

    private fun showSearch(q: String) {
        sectionJob?.cancel()
        mode="Search"; header.text="Search: $q"
        sectionJob = lifecycleScope.launch { container.database.videoDao().searchVideos(q).collectLatest { adapter.submit(it) } }
    }

    private fun play(video: VideoEntity) {
        if (video.uri.isBlank()) {
            currentFolder=video.folderPath
            sectionJob?.cancel()
            sectionJob = lifecycleScope.launch { container.database.videoDao().observeVideosInFolder(video.folderPath).collectLatest { adapter.submit(it) } }
            header.text=video.folderName
            return
        }
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("video_id",video.id).putExtra("video_uri",video.uri).putExtra("video_name",video.displayName))
    }

    private fun showVideoMenu(video: VideoEntity) {
        if (video.uri.isBlank()) return
        val options=arrayOf(if(video.isFavorite) "Remove favorite" else "Add to favorites","Share","Rename","Delete","Details","Assign category")
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle(video.displayName).setItems(options) { _,which ->
            when(which) {
                0 -> lifecycleScope.launch { container.database.videoDao().setFavorite(video.id,!video.isFavorite) }
                1 -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType(video.mimeType ?: "video/*").putExtra(Intent.EXTRA_STREAM,Uri.parse(video.uri)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),"Share video"))
                2 -> {
                    val input=EditText(this).apply { setText(video.displayName); setSingleLine(true) }
                    androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Rename video").setView(input)
                        .setNegativeButton("Cancel",null).setPositiveButton("Save") { _,_ ->
                            val newName=input.text.toString().trim()
                            if(newName.isNotBlank()) renameMedia(Uri.parse(video.uri),newName)
                        }.show()
                }
                3 -> androidx.appcompat.app.AlertDialog.Builder(this).setMessage("Delete this video from your device?")
                    .setNegativeButton("Cancel",null).setPositiveButton("Delete") { _,_ -> deleteMedia(Uri.parse(video.uri)) }.show()
                4 -> Toast.makeText(this,"${video.folderPath}\\n${video.width}×${video.height}",Toast.LENGTH_LONG).show()
                5 -> {
                    val cats=arrayOf("NEXUS_DOWNLOADS","QUICK_SHARE","CAMERA","SCREEN_RECORDINGS","WHATSAPP","TELEGRAM","BLUETOOTH","OTHER")
                    androidx.appcompat.app.AlertDialog.Builder(this).setItems(cats) { _,i ->
                        lifecycleScope.launch { container.database.videoDao().setCategory(video.id,cats[i]) }
                    }.show()
                }
            }
        }.show()
    }

    private fun deleteMedia(uri: Uri) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                val request = MediaStore.createDeleteRequest(contentResolver, listOf(uri))
                mediaRequestLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
            } else {
                contentResolver.delete(uri, null, null)
                container.repository.requestRefresh(true)
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Android did not allow deleting this file.", Toast.LENGTH_LONG).show()
        }
    }

    private fun renameMedia(uri: Uri, newName: String) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                val request = MediaStore.createWriteRequest(contentResolver, listOf(uri))
                pendingRenameUri = uri
                pendingRenameName = newName
                mediaRequestLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
            } else {
                val updated = contentResolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, newName) }, null, null)
                if (updated > 0) container.repository.requestRefresh(true)
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Rename is restricted by Android for this file.", Toast.LENGTH_LONG).show()
        }
    }

    private fun showSettings() {
        adapter.submit(emptyList())
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("NEXUS Settings")
            .setMessage("Theme: Pure Black\\nPlayback: Resume last position\\nLibrary: Automatic MediaStore scanning\\nStorage: Android system permissions")
            .setPositiveButton("Refresh library") { _, _ -> container.repository.requestRefresh(true) }
            .setNeutralButton("Clear watch history") { _, _ ->
                lifecycleScope.launch {
                    container.database.videoDao().clearAllProgress()
                    Toast.makeText(this@MainActivity, "Watch history cleared", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }
}
