package com.nexus.videoplayer.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

// Schemas are exported to app/schemas so later stages can add proper migrations
// (history and favorites must survive updates, so we never use destructive migration).
@Database(entities = [VideoEntity::class], version = 2, exportSchema = true)
abstract class NexusDatabase : RoomDatabase() {

    abstract fun videoDao(): VideoDao

    companion object {
        private val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE videos ADD COLUMN isFavorite INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE videos ADD COLUMN progressMs INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE videos ADD COLUMN lastPlayedSec INTEGER NOT NULL DEFAULT 0")
            }
        }
        fun create(context: Context): NexusDatabase =
            Room.databaseBuilder(context.applicationContext, NexusDatabase::class.java, "nexus.db")
                .addMigrations(MIGRATION_1_2)
                .build()
    }
}
