package com.nexus.videoplayer.util

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

object PermissionHelper {

    enum class Access {
        /** All videos on the device are readable. */
        FULL,

        /** Android 14+: user picked "Select photos and videos"; only those are readable. */
        PARTIAL,

        NONE
    }

    /** Only the permissions the current Android version actually needs. */
    fun requiredPermissions(): Array<String> = when {
        Build.VERSION.SDK_INT >= 34 -> arrayOf(
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
        )
        Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_VIDEO)
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    fun access(context: Context): Access {
        fun granted(permission: String) =
            ContextCompat.checkSelfPermission(context, permission) ==
                PackageManager.PERMISSION_GRANTED

        return when {
            Build.VERSION.SDK_INT >= 34 -> when {
                granted(Manifest.permission.READ_MEDIA_VIDEO) -> Access.FULL
                granted(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) -> Access.PARTIAL
                else -> Access.NONE
            }
            Build.VERSION.SDK_INT >= 33 ->
                if (granted(Manifest.permission.READ_MEDIA_VIDEO)) Access.FULL else Access.NONE
            else ->
                if (granted(Manifest.permission.READ_EXTERNAL_STORAGE)) Access.FULL else Access.NONE
        }
    }

    /**
     * True when the system will no longer show the permission dialog (user chose
     * "Don't allow" twice, or revoked it in settings). We then send them to app settings.
     */
    fun mustOpenSettings(activity: Activity, requestedBefore: Boolean): Boolean {
        if (!requestedBefore) return false
        return requiredPermissions().none {
            ActivityCompat.shouldShowRequestPermissionRationale(activity, it)
        }
    }
}
