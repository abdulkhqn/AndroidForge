package com.nexus.videoplayer.ui

import com.nexus.videoplayer.data.db.CategoryCount
import com.nexus.videoplayer.data.db.FolderSummary

data class LibraryUiState(
    val folders: List<FolderSummary> = emptyList(),
    val categories: List<CategoryCount> = emptyList(),
    val scanning: Boolean = false,
    /** False until the database has delivered its first result. */
    val loaded: Boolean = false
)
