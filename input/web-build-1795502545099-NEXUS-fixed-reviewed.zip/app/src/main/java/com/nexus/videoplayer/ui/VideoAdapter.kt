package com.nexus.videoplayer.ui

import android.graphics.Bitmap
import android.os.Build
import android.provider.MediaStore
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.nexus.videoplayer.data.db.VideoEntity
import java.util.concurrent.Executors

class VideoAdapter(
    private val onClick: (VideoEntity) -> Unit,
    private val onLongClick: (VideoEntity) -> Unit
) : RecyclerView.Adapter<VideoAdapter.Holder>() {
    private val items = mutableListOf<VideoEntity>()
    private val executor = Executors.newFixedThreadPool(2)
    fun submit(list: List<VideoEntity>) {
        items.clear(); items.addAll(list); notifyDataSetChanged()
    }
    class Holder(val row: LinearLayout, val thumb: ImageView, val title: TextView, val meta: TextView) : RecyclerView.ViewHolder(row)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val c = parent.context
        val row = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(14, 10, 14, 10)
            setBackgroundColor(0xFF151515.toInt())
            val lp = RecyclerView.LayoutParams(-1, 86); lp.setMargins(12, 5, 12, 5); layoutParams = lp
        }
        val image = ImageView(c).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(0xFF292929.toInt()) }
        row.addView(image, LinearLayout.LayoutParams(104, 66))
        val texts = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(12,0,0,0) }
        val title = TextView(c).apply { textSize = 14f; setTextColor(-1); maxLines = 2 }
        val meta = TextView(c).apply { textSize = 12f; setTextColor(0xFFAAAAAA.toInt()) }
        texts.addView(title); texts.addView(meta); row.addView(texts, LinearLayout.LayoutParams(0,-2,1f))
        return Holder(row,image,title,meta)
    }
    override fun onBindViewHolder(h: Holder, position: Int) {
        val item = items[position]
        h.title.text = item.displayName
        val mins = item.durationMs / 60000
        h.meta.text = "${mins} min  •  ${android.text.format.Formatter.formatShortFileSize(h.itemView.context,item.sizeBytes)}" +
            if (item.progressMs > 0) "  •  Resume ${item.progressMs/60000}m" else ""
        h.thumb.setImageResource(android.R.drawable.ic_media_play)
        if (Build.VERSION.SDK_INT >= 29) executor.execute {
            try {
                val bmp: Bitmap? = h.itemView.context.contentResolver.loadThumbnail(
                    android.net.Uri.parse(item.uri), android.util.Size(320, 180), null
                )
                h.itemView.post { if (h.bindingAdapterPosition == position) h.thumb.setImageBitmap(bmp) }
            } catch (_: Exception) { }
        }
        h.row.setOnClickListener { onClick(item) }
        h.row.setOnLongClickListener { onLongClick(item); true }
    }
    override fun getItemCount() = items.size
}
