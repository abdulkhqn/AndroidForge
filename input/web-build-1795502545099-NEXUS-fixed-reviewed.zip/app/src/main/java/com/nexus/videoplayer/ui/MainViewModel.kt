package com.nexus.videoplayer.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexus.videoplayer.NexusApp
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.stateIn

@OptIn(FlowPreview::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repository = (app as NexusApp).container.repository

    // Debounce: a scan writes in batches and Room re-emits after each one. Without this the
    // list would be re-diffed many times per second on weak devices.
    val state: StateFlow<LibraryUiState> = combine(
        repository.folders.debounce(UI_DEBOUNCE_MS),
        repository.categoryCounts.debounce(UI_DEBOUNCE_MS),
        repository.scanning
    ) { folders, categories, scanning ->
        LibraryUiState(folders = folders, categories = categories, scanning = scanning, loaded = true)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), LibraryUiState())

    fun refresh(force: Boolean) = repository.requestRefresh(force)

    private companion object {
        const val UI_DEBOUNCE_MS = 250L
    }
}
