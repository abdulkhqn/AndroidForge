package com.nexus.videoplayer.domain

/** Smart categories. The enum name is what is stored in the database. */
enum class Category {
    NEXUS_DOWNLOADS,
    QUICK_SHARE,
    CAMERA,
    SCREEN_RECORDINGS,
    WHATSAPP,
    TELEGRAM,
    BLUETOOTH,
    OTHER;

    companion object {
        fun fromName(name: String?): Category =
            entries.firstOrNull { it.name == name } ?: OTHER
    }
}
