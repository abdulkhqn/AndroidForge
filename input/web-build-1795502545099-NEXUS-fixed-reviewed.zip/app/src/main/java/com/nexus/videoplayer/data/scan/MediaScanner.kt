package com.nexus.videoplayer.data.scan

import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import com.nexus.videoplayer.data.db.VideoEntity
import com.nexus.videoplayer.domain.SourceClassifier
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive

/**
 * Reads real videos from MediaStore. Rows are delivered in batches so a library with tens of
 * thousands of videos never has to sit in memory all at once (important on low-RAM devices).
 * Call from a background dispatcher.
 */
class MediaScanner(private val context: Context) {

    suspend fun scan(batchSize: Int, onBatch: suspend (List<VideoEntity>) -> Unit) {
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI

        @Suppress("DEPRECATION")
        val dataColumn = MediaStore.Video.Media.DATA

        val projection = buildList {
            add(MediaStore.Video.Media._ID)
            add(MediaStore.Video.Media.DISPLAY_NAME)
            add(dataColumn)
            add(MediaStore.Video.Media.SIZE)
            add(MediaStore.Video.Media.DURATION)
            add(MediaStore.Video.Media.DATE_ADDED)
            add(MediaStore.Video.Media.DATE_MODIFIED)
            add(MediaStore.Video.Media.WIDTH)
            add(MediaStore.Video.Media.HEIGHT)
            add(MediaStore.Video.Media.MIME_TYPE)
            if (Build.VERSION.SDK_INT >= 29) {
                add(MediaStore.Video.Media.RELATIVE_PATH)
                add(MediaStore.Video.Media.OWNER_PACKAGE_NAME)
            }
        }.toTypedArray()

        // A null cursor means the query failed. Throw instead of treating it as "no videos",
        // otherwise the caller would delete the whole library.
        val cursor = context.contentResolver.query(
            collection,
            projection,
            "${MediaStore.Video.Media.SIZE} > 0",
            null,
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        ) ?: throw IllegalStateException("MediaStore returned a null cursor")

        cursor.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val dataCol = c.getColumnIndexOrThrow(dataColumn)
            val sizeCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            val durCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val addedCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
            val modCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)
            val widthCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
            val heightCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
            val mimeCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
            val relCol =
                if (Build.VERSION.SDK_INT >= 29) c.getColumnIndex(MediaStore.Video.Media.RELATIVE_PATH) else -1
            val ownerCol =
                if (Build.VERSION.SDK_INT >= 29) c.getColumnIndex(MediaStore.Video.Media.OWNER_PACKAGE_NAME) else -1

            val batch = ArrayList<VideoEntity>(batchSize)

            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                val filePath = c.getString(dataCol)
                val relativePath = if (relCol >= 0) c.getString(relCol) else null
                val owner = if (ownerCol >= 0) c.getString(ownerCol) else null

                val folderPath = resolveFolderPath(filePath, relativePath)
                val folderName = folderPath.trimEnd('/').substringAfterLast('/').ifEmpty { "Unknown" }

                batch.add(
                    VideoEntity(
                        id = id,
                        uri = ContentUris.withAppendedId(collection, id).toString(),
                        displayName = c.getString(nameCol) ?: "video_$id",
                        folderPath = folderPath,
                        folderName = folderName,
                        sizeBytes = c.getLong(sizeCol),
                        durationMs = c.getLong(durCol),
                        dateAddedSec = c.getLong(addedCol),
                        dateModifiedSec = c.getLong(modCol),
                        width = c.getInt(widthCol),
                        height = c.getInt(heightCol),
                        mimeType = c.getString(mimeCol),
                        ownerPackage = owner?.takeIf { it.isNotBlank() },
                        autoCategory = SourceClassifier.classify(folderPath, owner).name
                    )
                )

                if (batch.size >= batchSize) {
                    currentCoroutineContext().ensureActive()
                    onBatch(batch.toList())
                    batch.clear()
                }
            }
            if (batch.isNotEmpty()) onBatch(batch.toList())
        }
    }

    private fun resolveFolderPath(filePath: String?, relativePath: String?): String {
        if (!filePath.isNullOrEmpty()) {
            val parent = filePath.substringBeforeLast('/', "")
            if (parent.isNotEmpty()) return parent
        }
        if (!relativePath.isNullOrEmpty()) return "/" + relativePath.trim('/')
        return "/unknown"
    }
}
