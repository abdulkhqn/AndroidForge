package com.nexus.videoplayer.data.repo

import android.content.Context
import android.database.ContentObserver
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import com.nexus.videoplayer.data.db.CategoryCount
import com.nexus.videoplayer.data.db.FolderSummary
import com.nexus.videoplayer.data.db.VideoDao
import com.nexus.videoplayer.data.scan.MediaScanner
import com.nexus.videoplayer.util.Prefs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * Single source of truth for the video library. The UI only ever observes the database;
 * scanning writes to it in the background.
 */
class LibraryRepository(
    private val context: Context,
    private val dao: VideoDao,
    private val scanner: MediaScanner,
    private val prefs: Prefs,
    private val scope: CoroutineScope
) {

    val folders: Flow<List<FolderSummary>> = dao.observeFolders()
    val categoryCounts: Flow<List<CategoryCount>> = dao.observeCategoryCounts()

    private val _scanning = MutableStateFlow(false)
    val scanning: StateFlow<Boolean> = _scanning.asStateFlow()

    private val scanMutex = Mutex()
    private val pendingScans = AtomicInteger(0)
    private val scannedThisProcess = AtomicBoolean(false)

    // --- Live updates: new downloads, camera videos, Quick Share files, etc. -------------

    private val handler = Handler(Looper.getMainLooper())
    private var observing = false
    private val debouncedScan = Runnable { requestRefresh(force = true) }
    private val observer = object : ContentObserver(handler) {
        override fun onChange(selfChange: Boolean) {
            // MediaStore can fire many times for one file (pending -> done); coalesce them.
            handler.removeCallbacks(debouncedScan)
            handler.postDelayed(debouncedScan, OBSERVER_DEBOUNCE_MS)
        }
    }

    /** Call on the main thread once video access is granted. Safe to call repeatedly. */
    fun startObserving() {
        if (observing) return
        context.contentResolver.registerContentObserver(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            true,
            observer
        )
        observing = true
    }

    // --- Scanning ----------------------------------------------------------------------

    /**
     * Schedules a library sync on the app scope. With [force] = false the scan is skipped when
     * MediaStore reports nothing changed since the last one, so calling this from onStart is cheap.
     */
    fun requestRefresh(force: Boolean) {
        pendingScans.incrementAndGet()
        _scanning.value = true
        scope.launch {
            try {
                refresh(force)
            } finally {
                if (pendingScans.decrementAndGet() == 0) _scanning.value = false
            }
        }
    }

    private suspend fun refresh(force: Boolean) {
        scanMutex.withLock { runScan(force) }
    }

    private suspend fun runScan(force: Boolean) {
        val generation = currentGeneration()
        if (!force && !shouldScan(generation)) return

        try {
            withContext(Dispatchers.IO) { syncLibrary() }
            scannedThisProcess.set(true)
            if (generation != null) {
                prefs.scanGeneration = generation
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // e.g. permission revoked mid-scan. The database is left untouched.
            Log.e(TAG, "Library scan failed", e)
        }
    }

    private suspend fun shouldScan(generation: Long?): Boolean {
        // Android 10 and below have no generation counter: scan once per process start,
        // afterwards the ContentObserver (or manual refresh) triggers forced scans.
        if (generation == null) return !scannedThisProcess.get()
        if (generation != prefs.scanGeneration) return true
        return !scannedThisProcess.get() && dao.count() == 0
    }

    private fun currentGeneration(): Long? {
        if (Build.VERSION.SDK_INT < 30) return null
        return try {
            MediaStore.getGeneration(context, MediaStore.VOLUME_EXTERNAL)
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun syncLibrary() {
        val manual = dao.manualCategories().associate { it.id to it.manualCategory }
        val existingIds = dao.allIds()
        val seen = HashSet<Long>(existingIds.size.coerceAtLeast(16))

        scanner.scan(BATCH_SIZE) { batch ->
            // Keep the user's manual category when a video is re-scanned.
            val merged = batch.map { video ->
                val chosen = manual[video.id]
                if (chosen != null) video.copy(manualCategory = chosen) else video
            }
            dao.upsertAll(merged)
            batch.forEach { seen.add(it.id) }
        }

        // Only reached if the whole query succeeded: remove videos that no longer exist.
        existingIds.filterNot { it in seen }
            .chunked(DELETE_CHUNK)
            .forEach { dao.deleteByIds(it) }
    }

    private companion object {
        const val TAG = "NexusLibrary"
        const val BATCH_SIZE = 300
        const val DELETE_CHUNK = 500
        const val OBSERVER_DEBOUNCE_MS = 1500L
    }
}
