package com.nexus.videoplayer.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * One row per video known to MediaStore. This table is a cache of MediaStore plus the user's own
 * choices (manualCategory), which a rescan must never overwrite.
 */
@Entity(
    tableName = "videos",
    indices = [Index("folderPath"), Index("autoCategory"), Index("dateAddedSec")]
)
data class VideoEntity(
    @PrimaryKey val id: Long,
    val uri: String,
    val displayName: String,
    val folderPath: String,
    val folderName: String,
    val sizeBytes: Long,
    val durationMs: Long,
    val dateAddedSec: Long,
    val dateModifiedSec: Long,
    val width: Int,
    val height: Int,
    val mimeType: String?,
    val ownerPackage: String?,
    val autoCategory: String,
    val manualCategory: String? = null,
    val isFavorite: Boolean = false,
    val progressMs: Long = 0L,
    val lastPlayedSec: Long = 0L
)
