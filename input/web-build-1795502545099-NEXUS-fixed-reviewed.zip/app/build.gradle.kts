import java.io.File

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

// Shared CI keystore (public, throwaway). It only exists so every CI build is signed with the
// SAME key, which lets you install stage N+1 over stage N without uninstalling.
// For a real Play Store release, provide your own keystore via the NEXUS_* env vars below.
val ciKeystore: File = rootProject.file("keystore/nexus-ci.jks")

android {
    namespace = "com.nexus.videoplayer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nexus.videoplayer"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.0.0"

        // 32-bit ARM (low-end devices) + 64-bit ARM. One universal APK carries both.
        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a")
        }
    }

    signingConfigs {
        if (ciKeystore.exists()) {
            getByName("debug") {
                storeFile = ciKeystore
                storePassword = "nexus-ci"
                keyAlias = "nexus"
                keyPassword = "nexus-ci"
            }
        }
        create("release") {
            val envFile = System.getenv("NEXUS_KEYSTORE_FILE")
            if (!envFile.isNullOrBlank() && File(envFile).exists()) {
                storeFile = File(envFile)
                storePassword = System.getenv("NEXUS_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("NEXUS_KEY_ALIAS")
                keyPassword = System.getenv("NEXUS_KEY_PASSWORD")
            } else if (ciKeystore.exists()) {
                storeFile = ciKeystore
                storePassword = "nexus-ci"
                keyAlias = "nexus"
                keyPassword = "nexus-ci"
            }
        }
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("release")
        }
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    testImplementation("junit:junit:4.13.2")
}
