# NEXUS – Android Offline Video Player

Kotlin + XML + RecyclerView, Media3 ExoPlayer, Room database.
Package: `com.nexus.videoplayer` · minSdk 26 · targetSdk 35.
ABIs: `armeabi-v7a` and `arm64-v8a`.

## Included
- Stage 1: permissions, MediaStore scanner, Room cache, ContentObserver, CI workflow.
- Stage 2: folder list, video library, MediaStore thumbnails, folder drill-down.
- Stage 3: Media3 playback, seek/play/pause, playback speed, orientation toggle, PiP entry, basic swipe seeking.
- Stage 4: persistent playback position, resume on next open, history, favorites.
- Stage 5: search, sharing, delete attempt through MediaStore, manual category assignment, settings entry point.
- Stage 6: RecyclerView, batched scanner, debounced updates, background thumbnail loading, black theme.
- Stage 7: GitHub Actions debug/release APK artifacts and unit tests.

## Build
Push to `main` or `master`. GitHub Actions builds APKs and uploads:
- `NEXUS-debug-apk`
- `NEXUS-release-apk`

Local build requires JDK 17, Android SDK 35 and Gradle 8.9:
`gradle :app:assembleDebug`

## Important Android limitations
- MediaStore generally cannot prove which browser transferred a file when multiple apps save into the same folder. NEXUS uses path/owner metadata and offers manual category assignment.
- Android may require a system confirmation UI for deleting shared media. Some devices restrict file rename/move operations; this build does not silently move or rename originals.
- PiP depends on Android/device support and system settings.
- Codec/container playback depends on codecs available on the device.

## Signing
The included CI keystore is a shared demo key, not suitable for publishing. Configure repository secrets for a private release signing key before public distribution.
