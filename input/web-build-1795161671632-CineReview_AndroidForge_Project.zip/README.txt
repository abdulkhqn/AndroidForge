CineReview AndroidForge project

This is a minimal Android WebView wrapper. It loads the live CineReview website from:
https://main.cinereview.workers.dev/

The app needs an internet connection. Website content and backend data remain hosted online,
so updates to the hosted website can appear in the app without rebuilding the APK.

Build with AndroidForge:
1. Upload this ZIP (not the original HTML website ZIP).
2. Target platform: Android APK.
3. Build variant: debug (recommended for first test) or auto.
4. Start Build and download the APK artifact when complete.

If your live CineReview website URL has changed, replace START_URL in:
app/src/main/java/com/cinereview/app/MainActivity.java
then rebuild the ZIP.

This project does not include a signing key. AndroidForge debug APKs are for testing.
