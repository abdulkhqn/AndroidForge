(function () {
  "use strict";
  // Sends JavaScript errors from the public site to the admin "Site errors" list.
  // Limits: 20 reports per visit, same message only once, text is cut short.
  const cfg = window.CINE_SUPABASE || {};
  const BASE = (cfg.url || "").replace(/\/$/, "");
  const ANON = cfg.anonKey || "";
  let sent = 0;
  const seen = new Set();

  function report(message, source) {
    if (!BASE || !ANON || sent >= 20) return;
    const msg = String(message || "Unknown error").slice(0, 300);
    const key = msg + "|" + String(source || "").slice(0, 80);
    if (seen.has(key)) return;
    seen.add(key);
    sent++;
    fetch(BASE + "/rest/v1/site_errors", {
      method: "POST",
      headers: { apikey: ANON, Authorization: "Bearer " + ANON, "Content-Type": "application/json", Prefer: "return=minimal" },
      body: JSON.stringify([{
        message: msg,
        source: String(source || "").slice(0, 200),
        page: location.pathname.slice(0, 120),
        user_agent: navigator.userAgent.slice(0, 200),
      }]),
      keepalive: true,
    }).catch(function () {});
  }

  window.addEventListener("error", function (e) {
    report(e.message, (e.filename || "") + ":" + (e.lineno || 0));
  });
  window.addEventListener("unhandledrejection", function (e) {
    const r = e.reason;
    report((r && r.message) || String(r), "promise");
  });
})();
