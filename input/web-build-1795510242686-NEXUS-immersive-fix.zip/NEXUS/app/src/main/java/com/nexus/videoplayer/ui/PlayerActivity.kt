package com.nexus.videoplayer.ui

import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.nexus.videoplayer.NexusApp
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs

class PlayerActivity : AppCompatActivity() {
    private val container get() = (application as NexusApp).container
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private var videoId = 0L
    private var saveJob: Job? = null
    private var downX = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enterImmersiveMode()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        videoId = intent.getLongExtra("video_id", 0L)
        val uri = intent.getStringExtra("video_uri") ?: run { finish(); return }
        val name = intent.getStringExtra("video_name") ?: "NEXUS Player"

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
        }
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 8, 12, 8)
        }
        top.addView(Button(this).apply {
            text = "‹"
            contentDescription = "Back"
            setOnClickListener { finish() }
        })
        top.addView(TextView(this).apply {
            text = name
            textSize = 15f
            setTextColor(-1)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(Button(this).apply {
            text = "⋮"
            contentDescription = "Playback options"
            setOnClickListener { speedMenu() }
        })
        layout.addView(top)

        playerView = PlayerView(this).apply {
            useController = true
            controllerShowTimeoutMs = 3500
            setBackgroundColor(0xFF000000.toInt())
        }
        layout.addView(playerView, LinearLayout.LayoutParams(-1, 0, 1f))

        val actions = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 12)
        }
        listOf("−10s", "Play/Pause", "+10s", "Speed", "Rotate", "Lock").forEach { label ->
            actions.addView(Button(this).apply {
                text = label
                textSize = 11f
                setOnClickListener {
                    val p = player
                    when (label) {
                        "−10s" -> p?.seekTo((p.currentPosition - 10000).coerceAtLeast(0))
                        "+10s" -> p?.seekTo(p.currentPosition + 10000)
                        "Play/Pause" -> if (p?.isPlaying == true) p.pause() else p?.play()
                        "Speed" -> speedMenu()
                        "Rotate" -> requestedOrientation = if (resources.configuration.orientation == 1)
                            ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                        "Lock" -> Toast.makeText(this@PlayerActivity, "Player lock will be added in the custom controls update.", Toast.LENGTH_SHORT).show()
                    }
                }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        layout.addView(actions)
        setContentView(layout)
        enterImmersiveMode()

        val exo = ExoPlayer.Builder(this).build()
        player = exo
        playerView.player = exo
        exo.setMediaItem(MediaItem.fromUri(uri))

        lifecycleScope.launch {
            container.database.videoDao().observeAllVideos().collect { videos ->
                val progress = videos.firstOrNull { it.id == videoId }?.progressMs ?: 0L
                if (progress > 0 && exo.currentPosition == 0L) exo.seekTo(progress)
            }
        }
        exo.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) lifecycleScope.launch {
                    container.database.videoDao().clearProgress(videoId)
                }
            }
        })
        exo.prepare()
        exo.playWhenReady = true

        saveJob = lifecycleScope.launch {
            while (isActive) {
                delay(5000)
                saveProgress()
            }
        }
        playerView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.x; true }
                MotionEvent.ACTION_UP -> {
                    val dx = event.x - downX
                    if (abs(dx) > 80) {
                        exo.seekTo((exo.currentPosition + (dx * 80).toLong()).coerceAtLeast(0))
                        true
                    } else false
                }
                else -> true
            }
        }
    }

    /** Hides status bar (clock, network, battery) and navigation bar while video plays. */
    private fun enterImmersiveMode() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersiveMode()
    }

    private fun speedMenu() {
        val speeds = arrayOf("0.5x", "0.75x", "1.0x", "1.25x", "1.5x", "1.75x", "2.0x")
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Playback speed")
            .setItems(speeds) { _, i -> player?.setPlaybackSpeed(speeds[i].removeSuffix("x").toFloat()) }
            .setOnDismissListener { enterImmersiveMode() }
            .show()
    }

    private suspend fun saveProgress() {
        val p = player ?: return
        if (videoId != 0L && p.currentPosition > 0) {
            container.database.videoDao().saveProgress(videoId, p.currentPosition, System.currentTimeMillis() / 1000)
        }
    }

    override fun onPause() { super.onPause(); lifecycleScope.launch { saveProgress() } }
    override fun onStop() { super.onStop(); lifecycleScope.launch { saveProgress() } }
    override fun onDestroy() {
        saveJob?.cancel()
        playerView.player = null
        player?.release()
        player = null
        super.onDestroy()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= 26 && player?.isPlaying == true) {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
        }
    }
}
