# Carrom AI — project scaffold (Step 1)

Visual assistant for "Disk Pool Carrom". It only *suggests* shots; the user always flicks the striker.

## Status
This step contains only the build configuration, manifest, resources and CI. Kotlin sources are added in later steps so that each module can be tested before the next is built.

## Files and their purpose
| File | Purpose |
|---|---|
| `settings.gradle.kts` | Declares repositories and includes the `app` module. |
| `build.gradle.kts` | Root build file; declares plugin versions only. |
| `gradle.properties` | Gradle memory limits and AndroidX flags. |
| `gradle/libs.versions.toml` | Single source of truth for dependency and plugin versions. |
| `app/build.gradle.kts` | SDK 26–36, ABI filters (armeabi-v7a + arm64-v8a), release shrinking, dependencies. |
| `app/proguard-rules.pro` | Keeps OpenCV JNI classes from being stripped by R8. |
| `app/src/main/AndroidManifest.xml` | Permissions (overlay, foreground service, media projection) and components. |
| `app/src/main/res/values/*.xml` | Palette (#090B10 background, #B6F36B accent) and dark theme. |
| `.github/workflows/android.yml` | Free GitHub Actions build for debug APK and optional signed release APK. |

## Setup you must do once
1. Generate the Gradle wrapper (the wrapper JAR is binary and not included here):
   `gradle wrapper --gradle-version 8.11.1` (install Gradle or open the project in Android Studio and run the wrapper task).
2. Commit `gradlew`, `gradlew.bat`, and `gradle/wrapper/` to the repository.

## Planned next steps
- Step 2: `PreferencesManager.kt`, splash, player selection screen.
- Step 3: `ScreenCaptureManager.kt` and the MediaProjection permission flow.
- Step 4: `ImageProcessor.kt`, `CoinDetector.kt`, `PocketDetector.kt` (OpenCV).
- Step 5: `CarromPhysicsEngine.kt`, `ShotCalculator.kt`.
- Step 6: `OverlayService.kt` and drawing on the overlay.
