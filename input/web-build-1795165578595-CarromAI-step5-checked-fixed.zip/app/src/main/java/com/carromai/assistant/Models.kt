package com.carromai.assistant

import android.graphics.PointF
import android.graphics.RectF

enum class CoinType { BLACK, WHITE, QUEEN, STRIKER }

/** A detected coin. Coordinates are in pixels of the loaded (possibly downscaled) bitmap. */
data class Coin(val center: PointF, val radius: Float, val type: CoinType)

/**
 * One suggested shot. bounce is null for a direct shot.
 * aimPoint is where the striker centre must touch the target.
 */
data class Shot(
    val striker: PointF,
    val target: Coin,
    val bounce: PointF?,
    val pocket: PointF,
    val aimPoint: PointF,
    val angleDeg: Float
)

data class DetectionResult(
    val board: RectF?,
    val coins: List<Coin>,
    val pockets: List<PointF>,
    val striker: Coin? = null,
    val shot: Shot? = null
)
