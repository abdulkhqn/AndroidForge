package com.carromai.assistant

import android.graphics.PointF
import android.graphics.RectF

/**
 * Estimates the four corner pockets from the board outline.
 * This is an approximation: the frame includes the rails, so the pockets are inset a little.
 * Exact pocket positions need calibration on real screenshots before the physics step.
 */
object PocketDetector {

    fun detect(board: RectF): List<PointF> {
        val inset = board.width() * 0.03f
        return listOf(
            PointF(board.left + inset, board.top + inset),
            PointF(board.right - inset, board.top + inset),
            PointF(board.left + inset, board.bottom - inset),
            PointF(board.right - inset, board.bottom - inset)
        )
    }
}
