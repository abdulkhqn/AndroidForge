package com.carromai.assistant

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.core.Rect
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.sqrt

/** Shared OpenCV helpers: loading, board outline detection, and drawing results. */
object ImageProcessor {

    fun init(): Boolean = OpenCVLoader.initLocal()

    /** Converts an ARGB bitmap to an RGBA Mat. Caller must release the Mat. */
    fun toRgba(bitmap: Bitmap): Mat {
        val mat = Mat()
        Utils.bitmapToMat(bitmap, mat)
        return mat
    }

    /** Largest roughly square outer contour covering at least 20% of the image, or null. */
    fun detectBoard(rgba: Mat): RectF? {
        val gray = Mat()
        val blurred = Mat()
        val edges = Mat()
        try {
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
            Imgproc.GaussianBlur(gray, blurred, Size(5.0, 5.0), 0.0)
            Imgproc.Canny(blurred, edges, 50.0, 150.0)

            val contours = ArrayList<MatOfPoint>()
            Imgproc.findContours(edges, contours, Mat(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)

            val imageArea = rgba.rows().toDouble() * rgba.cols()
            var best: Rect? = null
            var bestArea = 0.0
            for (contour in contours) {
                val r = Imgproc.boundingRect(contour)
                val aspect = r.width.toDouble() / r.height.toDouble()
                val area = r.width.toDouble() * r.height.toDouble()
                if (aspect in 0.75..1.33 && area > imageArea * 0.2 && area > bestArea) {
                    best = r
                    bestArea = area
                }
            }
            return best?.let {
                RectF(it.x.toFloat(), it.y.toFloat(), (it.x + it.width).toFloat(), (it.y + it.height).toFloat())
            }
        } finally {
            gray.release()
            blurred.release()
            edges.release()
        }
    }

    /** Draws board, coins, pockets, striker, and the suggested shot on a copy of the source. */
    fun annotate(source: Bitmap, result: DetectionResult): Bitmap {
        val out = source.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        val unit = out.width / 200f
        val green = Color.rgb(0x3C, 0xFF, 0x7A)
        val yellow = Color.rgb(0xFF, 0xD9, 0x3D)

        result.board?.let { canvas.drawRect(it, stroke(green, unit * 2)) }

        for (coin in result.coins) {
            val color = when (coin.type) {
                CoinType.BLACK -> Color.CYAN
                CoinType.WHITE -> Color.LTGRAY
                CoinType.QUEEN -> Color.RED
                CoinType.STRIKER -> Color.BLUE
            }
            canvas.drawCircle(coin.center.x, coin.center.y, coin.radius, stroke(color, unit))
        }
        for (pocket in result.pockets) {
            canvas.drawCircle(pocket.x, pocket.y, unit * 1.2f, fill(green))
        }
        result.striker?.let {
            canvas.drawCircle(it.center.x, it.center.y, it.radius, stroke(Color.BLUE, unit * 2))
        }

        result.shot?.let { shot ->
            val s = shot.striker
            val a = shot.aimPoint
            val t = shot.target.center

            canvas.drawLine(s.x, s.y, a.x, a.y, stroke(green, unit * 1.5f))
            drawArrowHead(canvas, s, a, unit * 4, stroke(green, unit * 1.5f))
            canvas.drawCircle(t.x, t.y, shot.target.radius * 1.3f, stroke(Color.WHITE, unit))

            val path = Path().apply {
                moveTo(t.x, t.y)
                shot.bounce?.let { lineTo(it.x, it.y) }
                lineTo(shot.pocket.x, shot.pocket.y)
            }
            canvas.drawPath(path, stroke(yellow, unit * 1.5f))

            val label = fill(Color.WHITE).apply { textSize = unit * 4 }
            canvas.drawText("${shot.angleDeg.toInt()}°", s.x + unit * 5, s.y - unit * 5, label)
        }
        return out
    }

    private fun drawArrowHead(canvas: Canvas, from: PointF, to: PointF, len: Float, paint: Paint) {
        val dx = to.x - from.x
        val dy = to.y - from.y
        val dist = sqrt(dx * dx + dy * dy)
        if (dist < 1f) return
        // Back-pointing direction, rotated by +30 and -30 degrees to form the two barbs.
        val bx = -dx / dist
        val by = -dy / dist
        for (sign in listOf(1f, -1f)) {
            val rx = bx * 0.866f - by * 0.5f * sign
            val ry = bx * 0.5f * sign + by * 0.866f
            canvas.drawLine(to.x, to.y, to.x + rx * len, to.y + ry * len, paint)
        }
    }

    private fun stroke(color: Int, width: Float): Paint = Paint().apply {
        style = Paint.Style.STROKE
        this.color = color
        strokeWidth = width
        isAntiAlias = true
    }

    private fun fill(color: Int): Paint = Paint().apply {
        style = Paint.Style.FILL
        this.color = color
        isAntiAlias = true
    }
}
