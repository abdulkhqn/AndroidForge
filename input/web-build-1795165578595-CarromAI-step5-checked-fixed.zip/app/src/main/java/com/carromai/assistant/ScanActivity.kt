package com.carromai.assistant

import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.carromai.assistant.databinding.ActivityScanBinding
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Picks an offline screenshot, runs the full review pipeline off the UI thread, and shows the annotated result. */
class ScanActivity : AppCompatActivity() {

    private lateinit var binding: ActivityScanBinding
    private val prefs by lazy { PreferencesManager(this) }
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var original: LoadedImage? = null
    private var annotated: Bitmap? = null

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) onImagePicked(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScanBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnPick.setOnClickListener { pickImage.launch("image/*") }
        binding.btnBack.setOnClickListener { finish() }
        binding.tvInfo.setText(R.string.scan_hint)
    }

    private fun onImagePicked(uri: Uri) {
        val side = when (prefs.getPlayerColor()) {
            PlayerColor.BLACK -> CoinType.BLACK
            PlayerColor.WHITE -> CoinType.WHITE
            null -> {
                binding.tvInfo.setText(R.string.scan_need_color)
                return
            }
        }
        val loaded = ImageLoader.load(this, uri)
        if (loaded == null) {
            binding.tvInfo.setText(R.string.scan_load_failed)
            return
        }
        releaseBitmaps()
        original = loaded
        binding.ivScreenshot.setImageBitmap(loaded.bitmap)
        binding.tvInfo.setText(R.string.scan_detecting)

        // Work on a private copy so re-picking an image cannot recycle a bitmap the worker is still using.
        val input = loaded.bitmap.copy(Bitmap.Config.ARGB_8888, false)
        worker.execute {
            val outcome = try {
                analyse(input, side)
            } finally {
                input.recycle()
            }
            mainHandler.post {
                if (!isDestroyed) showOutcome(outcome)
            }
        }
    }

    /** Full pipeline: board, coins, striker, pockets, best shot. Returns the annotated bitmap (or null) and text. */
    private fun analyse(input: Bitmap, side: CoinType): Pair<Bitmap?, String> {
        if (!ImageProcessor.init()) return null to getString(R.string.scan_cv_failed)

        val rgba = ImageProcessor.toRgba(input)
        try {
            val board = ImageProcessor.detectBoard(rgba)
                ?: return null to getString(R.string.scan_no_board)

            val all = CoinDetector.detect(rgba, board)
            val striker = ShotCalculator.findStriker(board, all)
            val coins = if (striker == null) all else all.filter { it.center != striker.center }
            val pockets = PocketDetector.detect(board)
            val shot = striker?.let { ShotCalculator.best(board, it, coins, pockets, side) }

            val counts = getString(
                R.string.scan_counts,
                coins.count { it.type == CoinType.BLACK },
                coins.count { it.type == CoinType.WHITE },
                coins.count { it.type == CoinType.QUEEN },
                pockets.size
            )
            val shotText = when {
                striker == null -> getString(R.string.scan_striker_missing)
                shot == null -> getString(R.string.scan_no_shot)
                shot.bounce == null -> getString(R.string.scan_shot_direct, shot.angleDeg.toInt())
                else -> getString(R.string.scan_shot_bounce, shot.angleDeg.toInt())
            }

            val picture = ImageProcessor.annotate(input, DetectionResult(board, coins, pockets, striker, shot))
            return picture to "$counts\n$shotText"
        } finally {
            rgba.release()
        }
    }

    private fun showOutcome(outcome: Pair<Bitmap?, String>) {
        val (picture, summary) = outcome
        if (picture == null) {
            binding.tvInfo.text = summary
            return
        }
        annotated?.recycle()
        annotated = picture
        binding.ivScreenshot.setImageBitmap(picture)
        binding.tvInfo.text = summary
    }

    private fun releaseBitmaps() {
        binding.ivScreenshot.setImageDrawable(null)
        original?.bitmap?.recycle()
        original = null
        annotated?.recycle()
        annotated = null
    }

    override fun onDestroy() {
        worker.shutdownNow()
        releaseBitmaps()
        super.onDestroy()
    }
}
