package com.carromai.assistant

import android.graphics.PointF
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.sqrt

/**
 * Finds the striker and ranks direct and one-cushion shots for the player's coins.
 * This is geometry only (straight lines and mirror reflections), not a full physics simulation.
 */
object ShotCalculator {

    private const val MAX_ANGLE_DEG = 45f
    private const val CUSHION_PENALTY = 25f

    private data class Wall(val vertical: Boolean, val value: Float)

    /** Striker is assumed to sit on the baseline (bottom part of the board) as the largest coin there. */
    fun findStriker(board: RectF, coins: List<Coin>): Coin? {
        val baselineY = board.top + board.height() * 0.8f
        return coins
            .filter { it.center.y > baselineY && it.center.x in board.left..board.right }
            .maxByOrNull { it.radius }
            ?.copy(type = CoinType.STRIKER)
    }

    /** Best shot for the player's coins (and queen). Returns null if nothing is clear. */
    fun best(board: RectF, striker: Coin, coins: List<Coin>, pockets: List<PointF>, side: CoinType): Shot? {
        val targets = coins.filter { it.type == side || it.type == CoinType.QUEEN }
        val walls = listOf(
            Wall(true, board.left), Wall(true, board.right),
            Wall(false, board.top), Wall(false, board.bottom)
        )
        var best: Shot? = null
        var bestScore = Float.MAX_VALUE

        fun offer(shot: Shot?, penalty: Float) {
            if (shot == null) return
            val score = shot.angleDeg + penalty
            if (score < bestScore) {
                bestScore = score
                best = shot
            }
        }

        for (target in targets) {
            for (pocket in pockets) {
                offer(candidate(board, striker, target, coins, pocket, pocket, null), 0f)
                for (wall in walls) {
                    val virtual = mirror(pocket, wall)
                    val bounce = intersect(target.center, virtual, wall, board) ?: continue
                    offer(candidate(board, striker, target, coins, virtual, pocket, bounce), CUSHION_PENALTY)
                }
            }
        }
        return best
    }

    private fun candidate(
        board: RectF,
        striker: Coin,
        target: Coin,
        coins: List<Coin>,
        virtualPocket: PointF,
        realPocket: PointF,
        bounce: PointF?
    ): Shot? {
        val tc = target.center
        val dx = virtualPocket.x - tc.x
        val dy = virtualPocket.y - tc.y
        val len = sqrt(dx * dx + dy * dy)
        if (len < 1f) return null

        // Striker centre must be one contact distance behind the target, on the line to the pocket.
        val contact = striker.radius + target.radius
        val aim = PointF(tc.x - dx / len * contact, tc.y - dy / len * contact)
        if (!inside(board, aim)) return null

        val clearance = striker.radius
        if (!clear(striker.center, aim, coins, target, clearance)) return null
        val pathClear = if (bounce == null) {
            clear(tc, realPocket, coins, target, clearance)
        } else {
            clear(tc, bounce, coins, target, clearance) && clear(bounce, realPocket, coins, target, clearance)
        }
        if (!pathClear) return null

        val angle = angleBetween(
            PointF(tc.x - striker.center.x, tc.y - striker.center.y),
            PointF(dx, dy)
        )
        if (angle > MAX_ANGLE_DEG) return null
        return Shot(striker.center, target, bounce, realPocket, aim, angle)
    }

    /** True if no other coin comes within clearance of the segment a-b (the target itself is ignored). */
    private fun clear(a: PointF, b: PointF, coins: List<Coin>, exclude: Coin, clearance: Float): Boolean =
        coins.none { c -> c.center != exclude.center && segmentDistance(c.center, a, b) < c.radius + clearance }

    private fun mirror(p: PointF, wall: Wall): PointF =
        if (wall.vertical) PointF(2 * wall.value - p.x, p.y) else PointF(p.x, 2 * wall.value - p.y)

    /** Where the segment from -> to crosses the wall, if it does so within the board. */
    private fun intersect(from: PointF, to: PointF, wall: Wall, board: RectF): PointF? {
        val fromCoord = if (wall.vertical) from.x else from.y
        val toCoord = if (wall.vertical) to.x else to.y
        val denom = toCoord - fromCoord
        if (abs(denom) < 1e-3f) return null
        val s = (wall.value - fromCoord) / denom
        if (s < 0f || s > 1f) return null
        val p = PointF(from.x + s * (to.x - from.x), from.y + s * (to.y - from.y))
        return if (inside(board, p)) p else null
    }

    private fun inside(board: RectF, p: PointF): Boolean =
        p.x in board.left..board.right && p.y in board.top..board.bottom

    private fun segmentDistance(p: PointF, a: PointF, b: PointF): Float {
        val vx = b.x - a.x
        val vy = b.y - a.y
        val len2 = vx * vx + vy * vy
        val t = if (len2 == 0f) 0f else (((p.x - a.x) * vx + (p.y - a.y) * vy) / len2).coerceIn(0f, 1f)
        val cx = a.x + t * vx - p.x
        val cy = a.y + t * vy - p.y
        return sqrt(cx * cx + cy * cy)
    }

    private fun angleBetween(u: PointF, v: PointF): Float {
        val dot = u.x * v.x + u.y * v.y
        val lu = sqrt(u.x * u.x + u.y * u.y)
        val lv = sqrt(v.x * v.x + v.y * v.y)
        if (lu == 0f || lv == 0f) return 180f
        val c = (dot / (lu * lv)).coerceIn(-1f, 1f)
        return Math.toDegrees(acos(c).toDouble()).toFloat()
    }
}
