package com.carromai.assistant

import android.graphics.PointF
import android.graphics.RectF
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Rect
import org.opencv.core.Scalar
import org.opencv.imgproc.Imgproc

/** Finds coins inside the board with Hough circles, then classifies each by its average colour. */
object CoinDetector {

    fun detect(rgba: Mat, board: RectF): List<Coin> {
        val left = board.left.toInt().coerceIn(0, rgba.cols() - 1)
        val top = board.top.toInt().coerceIn(0, rgba.rows() - 1)
        val w = board.width().toInt().coerceAtMost(rgba.cols() - left)
        val h = board.height().toInt().coerceAtMost(rgba.rows() - top)
        if (w < 50 || h < 50) return emptyList()

        val boardRgba = rgba.submat(Rect(left, top, w, h))
        val gray = Mat()
        val blurred = Mat()
        val circles = Mat()
        try {
            Imgproc.cvtColor(boardRgba, gray, Imgproc.COLOR_RGBA2GRAY)
            Imgproc.medianBlur(gray, blurred, 5)

            // Coin radius is a fixed fraction of the board side, so the search range scales with the board.
            val side = minOf(w, h).toDouble()
            val minR = (side * 0.014).toInt().coerceAtLeast(4)
            val maxR = (side * 0.026).toInt().coerceAtLeast(minR + 2)
            Imgproc.HoughCircles(
                blurred, circles, Imgproc.HOUGH_GRADIENT,
                1.2, minR * 1.8, 100.0, 30.0, minR, maxR
            )
            if (circles.empty()) return emptyList()

            val coins = mutableListOf<Coin>()
            for (i in 0 until circles.cols()) {
                val d = circles.get(0, i) ?: continue
                val cx = d[0]
                val cy = d[1]
                val r = d[2]
                val type = classify(boardRgba, cx, cy, r) ?: continue
                coins += Coin(
                    PointF((left + cx).toFloat(), (top + cy).toFloat()),
                    r.toFloat(),
                    type
                )
            }
            return coins
        } finally {
            boardRgba.release()
            gray.release()
            blurred.release()
            circles.release()
        }
    }

    /** Looks at the centre of the coin. Red means queen, bright means white, dark means black. */
    private fun classify(rgba: Mat, cx: Double, cy: Double, r: Double): CoinType? {
        val inner = (r * 0.6).toInt().coerceAtLeast(2)
        val x = (cx - inner).toInt()
        val y = (cy - inner).toInt()
        val size = inner * 2
        if (x < 0 || y < 0 || x + size > rgba.cols() || y + size > rgba.rows()) return null

        val patch = rgba.submat(Rect(x, y, size, size))
        val mask = Mat.zeros(size, size, CvType.CV_8UC1)
        try {
            Imgproc.circle(mask, Point(inner.toDouble(), inner.toDouble()), inner, Scalar(255.0), -1)
            val mean = Core.mean(patch, mask)
            val red = mean.`val`[0]
            val green = mean.`val`[1]
            val blue = mean.`val`[2]
            val luminance = 0.3 * red + 0.59 * green + 0.11 * blue
            return when {
                red > 140 && green < 100 && blue < 100 -> CoinType.QUEEN
                luminance > 170 -> CoinType.WHITE
                luminance < 90 -> CoinType.BLACK
                else -> null
            }
        } finally {
            patch.release()
            mask.release()
        }
    }
}
