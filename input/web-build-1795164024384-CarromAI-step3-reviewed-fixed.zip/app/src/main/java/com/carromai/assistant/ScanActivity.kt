package com.carromai.assistant

import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.carromai.assistant.databinding.ActivityScanBinding

/** Lets the player pick an offline game screenshot and confirms it loads correctly. */
class ScanActivity : AppCompatActivity() {

    private lateinit var binding: ActivityScanBinding
    private var current: LoadedImage? = null

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) onImagePicked(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScanBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnPick.setOnClickListener { pickImage.launch("image/*") }
        binding.btnBack.setOnClickListener { finish() }
        binding.tvInfo.setText(R.string.scan_hint)
    }

    private fun onImagePicked(uri: Uri) {
        val loaded = ImageLoader.load(this, uri)
        if (loaded == null) {
            binding.tvInfo.setText(R.string.scan_load_failed)
            return
        }
        // Free the previous bitmap before replacing it, so memory does not grow on repeated picks.
        current?.bitmap?.recycle()
        current = loaded
        binding.ivScreenshot.setImageBitmap(loaded.bitmap)
        binding.tvInfo.text = getString(
            R.string.scan_info,
            loaded.originalWidth,
            loaded.originalHeight
        )
    }

    override fun onDestroy() {
        binding.ivScreenshot.setImageDrawable(null)
        current?.bitmap?.recycle()
        current = null
        super.onDestroy()
    }
}
