package com.carromai.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri

/** Result of loading a screenshot. Original size is kept for mapping coordinates in later steps. */
data class LoadedImage(
    val bitmap: Bitmap,
    val originalWidth: Int,
    val originalHeight: Int
)

/** Loads gallery images at reduced size so large screenshots do not exhaust memory. */
object ImageLoader {

    private const val MAX_SIDE_PX = 1280

    fun load(context: Context, uri: Uri): LoadedImage? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, bounds)
        } ?: return null

        val width = bounds.outWidth
        val height = bounds.outHeight
        if (width <= 0 || height <= 0) return null

        var sample = 1
        while (maxOf(width, height) / sample > MAX_SIDE_PX) {
            sample *= 2
        }

        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        val bitmap = context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, options)
        } ?: return null

        return LoadedImage(bitmap, width, height)
    }
}
