package com.carromai.assistant

import android.app.Application

/** Application entry point. Holds no state yet; later steps add OpenCV init here. */
class CarromApp : Application()
