# Keep OpenCV JNI entry points; R8 would otherwise strip the native bindings.
-keep class org.opencv.** { *; }
