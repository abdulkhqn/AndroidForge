// Root build file: applies plugin versions to subprojects without activating them here.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
}
